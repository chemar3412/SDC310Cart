<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 70%; margin: 50px auto; border-collapse: collapse; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #f8f8f8; }
        .btn { text-decoration: none; padding: 2px 8px; border: 1px solid #ccc; background: #eee; color: #333; margin: 0 5px; border-radius: 3px; }
        .total-label { text-align: right; font-weight: bold; }
        .grand-total { font-weight: bold; font-size: 1.2em; background-color: #f0f0f0; }
    </style>
</head>
<body>

<h2 style="text-align:center;">Your Shopping Cart</h2>

<?php 

$cart = new CartModel();
$items = $cart -> getItems();
foreach ($items as $id => $item){
    echo $items['name'];
}

if (!empty($_SESSION['cart'])): ?>
    <table>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Subtotal</th>
            <th>Remove</th>
        </tr>

        <?php foreach ($_SESSION['cart'] as $id => $item): 
            $line_subtotal = $item['price'] * $item['quantity'];
        ?>
        <tr>
            <td><?php echo htmlspecialchars($item['name']); ?></td>
            <td>$<?php echo number_format($item['price'], 2); ?></td>
            <td>
                <!-- Links now point to the controller -->
                <a class="btn" href="../controller/cart_controller.php?action=decrease&id=<?php echo $id; ?>">-</a>
                <strong><?php echo $item['quantity']; ?></strong>
                <a class="btn" href="../controller/cart_controller.php?action=increase&id=<?php echo $id; ?>">+</a>
            </td>
            <td>$<?php echo number_format($line_subtotal, 2); ?></td>
            <td><a href="../controller/cart_controller.php?action=delete&id=<?php echo $id; ?>" style="color:red; text-decoration:none; font-weight:bold;">&times; Remove</a></td>
        </tr>
        <?php endforeach; ?>

        <!-- Summary Section using variables from Controller -->
        <tr>
            <td colspan="3" class="total-label">Items Total:</td>
            <td colspan="2">$<?php echo number_format($items_total, 2); ?></td>
        </tr>
        <tr>
            <td colspan="3" class="total-label">Tax (5%):</td>
            <td colspan="2">$<?php echo number_format($tax, 2); ?></td>
        </tr>
        <tr>
            <td colspan="3" class="total-label">Shipping (10%):</td>
            <td colspan="2">$<?php echo number_format($shipping, 2); ?></td>
        </tr>
        <tr class="grand-total">
            <td colspan="3" class="total-label">Order Total:</td>
            <td colspan="2">$<?php echo number_format($order_total, 2); ?></td>
        </tr>
    </table>

    <div style="text-align:center;">
        <a href="../controller/catalog_controller.php">Return to Catalog</a> | 
        <a href="checkout.php" style="color:green; font-weight:bold;">Proceed to Checkout</a>
    </div>
<?php else: ?>
    <div style="text-align:center; margin-top: 50px;">
        <h3>Your cart is currently empty!</h3>
        <a href="../controller/catalog_controller.php">Go back to the Catalog to add items.</a>
    </div>
<?php endif; ?>

</body>
</html>
