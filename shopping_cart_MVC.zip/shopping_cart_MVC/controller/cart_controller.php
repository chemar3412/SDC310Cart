<?php
require_once '../model/CartModel.php';

session_start();

// Initialize the Model
$cartModel = new CartModel();

// Handle Actions (Update Quantity or Remove)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    if ($action === 'delete') {
        $cartModel->removeItem($id);
    } else {
        $cartModel->updateQuantity($id, $action);
    }

    // Refresh the page to show changes
    header("Location: ../controller/cart_controller.php");
    exit;
}

// Prepare Data for the View
$cart_items = $cartModel->getItems();
$totals = $cartModel->getCalculations();

// Assign totals to individual variables to keep the View simple
$items_total = $totals['subtotal'];
$tax = $totals['tax'];
$shipping = $totals['shipping'];
$order_total = $totals['grand_total'];

// Load the View
include '../views/cart_view.php';
?>