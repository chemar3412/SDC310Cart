<?php
// 1. Include the Model class
require_once '../model/ProductModel.php';
require_once '../model/CartModel.php';

session_start();

// 2. Instantiate the Model
$productModel = new ProductModel();
$cartModel = new CartModel();

// --- ADD TO CART LOGIC ---
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $cost = $_POST['cost'];

    $cartModel->addItem($product_id, $product_name, $cost);

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] += 1;
    } else {
        $_SESSION['cart'][$product_id] = [
            'name' => $product_name,
            'price' => $cost,
            'quantity' => 1
        ];
    }
    echo "<script>alert('Item added to cart!');</script>";
}

// 3. Replace raw query with Model call
$result = $productModel->getCatalogItems();

// 4. Load the view as before
include '../view/catalog_view.php';
?>