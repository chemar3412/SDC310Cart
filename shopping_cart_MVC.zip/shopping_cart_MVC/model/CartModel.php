<?php
class CartModel {
    public function __construct() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
    }

    public function getItems() {
        return $_SESSION['cart'];
    }

    public function addItem($id, $name, $price) {
        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity'] += 1;
        } else {
            $_SESSION['cart'][$id] = [
                'name' => $name,
                'price' => $price,
                'quantity' => 1
            ];
        }
    }

    public function updateQuantity($id, $action) {
        if (isset($_SESSION['cart'][$id])) {
            if ($action === 'increase') {
                $_SESSION['cart'][$id]['quantity'] += 1;
            } elseif ($action === 'decrease') {
                $_SESSION['cart'][$id]['quantity'] -= 1;
                if ($_SESSION['cart'][$id]['quantity'] < 1) {
                    $this->removeItem($id);
                }
            }
        }
    }

    public function removeItem($id) {
        unset($_SESSION['cart'][$id]);
    }

    public function getCalculations() {
        $items_total = 0;
        foreach ($_SESSION['cart'] as $item) {
            $items_total += $item['price'] * $item['quantity'];
        }

        $tax = $items_total * 0.05;
        $shipping = $items_total * 0.10;

        return [
            'subtotal' => $items_total,
            'tax' => $tax,
            'shipping' => $shipping,
            'grand_total' => $items_total + $tax + $shipping
        ];
    }
}