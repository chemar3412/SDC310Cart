Here's the fixed PHP code:

<?php
class ProductModel {
    private $conn;

    public function __construct() {
        // Database connection details
        $hostname = "localhost";
        $username = "ecpi_user";
        $password = "Password1";
        $dbname = "products";

        $this->conn = mysqli_connect($hostname, $username, $password, $dbname);

        // Check connection
        if (!$this->conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
    }

    public function getCatalogItems() {
        // Query to get catalog items
        $query = "SELECT * FROM catalog";
        $result = mysqli_query($this->conn, $query);

        // Check if query was successful
        if (!$result) {
            die("Query failed: " . mysqli_error($this->conn));
        }

        return $result;
    }
}
?>